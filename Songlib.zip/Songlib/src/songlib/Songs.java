// Names: Joshua Hernandez-jih31 & 	John Lavin-jvl50
package songlib;

public class Songs {
    public String Songname;
    public String Artist;
    public String Album;
    public String Year;

    public Songs(String Songname,String Artist,String Album,String Year) {
        this.Songname = Songname;
        this.Artist= Artist;
        this.Album = Album;
        this.Year=Year;
        }
    public String getSongname() {
        return Songname;
    }
    public String getArtist() {
        return Artist;
    }
    public String getAlbum() {
        return Album;
    }
    public String getYear() {
        return Year;
    }
    public String toString() {
        return this.Songname + ":\n" + this.Artist;
    }
    public String fileString() {
        return this.Songname + "\n" + this.Artist + "\n" + this.Album + "\n" + this.Year + "\n";
    }
}
