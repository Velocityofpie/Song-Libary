// Names: Joshua Hernandez-jih31 & 	John Lavin-jvl50
package songlib;
import javafx.application.Application;

import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;


import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;


import javafx.application.Application;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Songlib extends Application {
	
	
	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/songlib/Temp2.fxml"));

            AnchorPane root = (AnchorPane) loader.load();
            primaryStage.setResizable(false);
            primaryStage.setTitle("Song Library");

            //Controller songController2 = fxmlLoader.getController();
            //songController2.start();
            Controller songController = 
                    loader.getController();
            songController.start(primaryStage);

            Scene scene = new Scene(root);
//            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
            primaryStage.setScene(scene);
            primaryStage.show();

			
		} catch(Exception e) {
			e.printStackTrace();
		}

	}
	

	public static void main(String[] args) {
		launch(args);
	}	
}
